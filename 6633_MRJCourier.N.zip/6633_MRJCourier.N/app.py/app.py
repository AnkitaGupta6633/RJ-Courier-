from flask import Flask, request, jsonify, render_template, session, redirect, url_for
import psycopg2
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Needed for session management

# Replace with your PostgreSQL credentials
def get_db_connection():
    conn = psycopg2.connect(
        dbname="Delivery",
        user="postgres",
        password="1234",
        host="localhost",
        port="5432"
    )
    return conn

# Routes for serving HTML pages
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/order')
def order():
    return render_template('order.html')

@app.route('/payment')
def payment():
    return render_template('payment.html')

@app.route('/tracking')
def tracking():
    return render_template('tracking.html')

@app.route('/user')
def user():
    return render_template('user.html')

# Registration with improved error handling
@app.route("/register", methods=["POST"])
def register_user():
    try:
        data = request.get_json()
        print(f"Registration data received: {data}")  # Debug logging
        
        if not all(key in data for key in ['name', 'email', 'password', 'username', 'phone']):
            return jsonify({"error": "Missing required fields"}), 400
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Check if email already exists
        cur.execute("SELECT email FROM profile WHERE email = %s", (data["email"],))
        if cur.fetchone():
            return jsonify({"error": "Email already registered"}), 400
        
        # Check if username already exists
        cur.execute("SELECT username FROM profile WHERE username = %s", (data["username"],))
        if cur.fetchone():
            return jsonify({"error": "Username already taken"}), 400
            
        hashed_password = generate_password_hash(data["password"])
        
        cur.execute(
            "INSERT INTO profile (name, email, password, username, phone) VALUES (%s, %s, %s, %s, %s)",
            (data["name"], data["email"], hashed_password, data["username"], data["phone"])
        )
        conn.commit()
        return jsonify({"message": "User registered successfully!"}), 201
        
    except Exception as e:
        print(f"Registration error: {e}")  # Debug logging
        if 'conn' in locals():
            conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Login route - Fixed to return user data
@app.route("/login", methods=["POST"])
def login_user():
    try:
        data = request.get_json()
        print(f"Login data received: {data}")  # Debug logging
        
        if not all(key in data for key in ['email', 'password']):
            return jsonify({"error": "Missing email or password"}), 400
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        cur.execute("SELECT id, name, email, password, username, phone FROM profile WHERE email = %s", (data["email"],))
        user = cur.fetchone()
        
        if not user:
            return jsonify({"error": "Invalid email or password"}), 401
            
        user_id, name, email, password_hash, username, phone = user
        
        if check_password_hash(password_hash, data["password"]):
            session['user_id'] = user_id
            session['email'] = email
            return jsonify({
                "message": "Login successful!",
                "user": {
                    "id": user_id,
                    "name": name,
                    "email": email,
                    "username": username,
                    "phone": phone
                }
            })
        else:
            return jsonify({"error": "Invalid email or password"}), 401
            
    except Exception as e:
        print(f"Login error: {e}")  # Debug logging
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Create new order
@app.route("/order", methods=["POST"])
def create_order():
    if 'user_id' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        data = request.get_json()
        print(f"Order data received: {data}")  # Debug logging
        
        required_fields = ['sender_name', 'sender_email', 'sender_address', 'receiver_name', 
                          'receiver_email', 'receiver_address', 'package_type', 'receiving_date']
        
        if not all(key in data for key in required_fields):
            return jsonify({"error": "Missing required fields"}), 400
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Insert order into database
        cur.execute(
            """INSERT INTO orders (user_id, sender_name, sender_email, sender_address, 
            receiver_name, receiver_email, receiver_address, package_type, receiving_date) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id""",
            (session['user_id'], data['sender_name'], data['sender_email'], data['sender_address'],
             data['receiver_name'], data['receiver_email'], data['receiver_address'],
             data['package_type'], data['receiving_date'])
        )
        
        order_id = cur.fetchone()[0]
        conn.commit()
        
        return jsonify({
            "message": "Order created successfully!",
            "order_id": order_id
        }), 201
        
    except Exception as e:
        print(f"Order creation error: {e}")  # Debug logging
        if 'conn' in locals():
            conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Get user's orders
@app.route("/orders", methods=["GET"])
def get_orders():
    if 'user_id' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        cur.execute("""
            SELECT id, sender_name, sender_email, receiver_name, receiver_email, 
                   package_type, receiving_date, order_date, status, payment_status, price
            FROM orders 
            WHERE user_id = %s 
            ORDER BY order_date DESC
        """, (session['user_id'],))
        
        rows = cur.fetchall()
        orders = []
        
        for row in rows:
            orders.append({
                "id": row[0],
                "sender_name": row[1],
                "sender_email": row[2],
                "receiver_name": row[3],
                "receiver_email": row[4],
                "package_type": row[5],
                "receiving_date": row[6].strftime('%Y-%m-%d') if row[6] else None,
                "order_date": row[7].strftime('%Y-%m-%d %H:%M') if row[7] else None,
                "status": row[8],
                "payment_status": row[9],
                "price": float(row[10]) if row[10] else None
            })
        
        return jsonify(orders)
        
    except Exception as e:
        print(f"Get orders error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Get user profile by ID
@app.route("/profile", methods=["GET"])
def get_profile():
    if 'user_id' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT name, email, username, phone FROM profile WHERE id = %s", (session['user_id'],))
        user = cur.fetchone()
        
        if user:
            return jsonify({
                "name": user[0],
                "email": user[1],
                "username": user[2],
                "phone": user[3]
            })
        else:
            return jsonify({"error": "User not found"}), 404
            
    except Exception as e:
        print(f"Profile error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Logout route
@app.route("/logout")
def logout():
    session.clear()
    return jsonify({"message": "Logged out successfully"})

# Get all users
@app.route("/users", methods=["GET"])
def get_users():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, name, email, username, phone FROM profile")
        rows = cur.fetchall()
        users = [{
            "id": r[0], 
            "name": r[1], 
            "email": r[2], 
            "username": r[3],
            "phone": r[4]
        } for r in rows]
        return jsonify(users)
    except Exception as e:
        print(f"Get users error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Payment processing endpoint
@app.route("/payment", methods=["POST"])
def process_payment():
    if 'user_id' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['order_id', 'method', 'amount', 'payer_name', 'payer_email', 'payer_phone']
        if not all(key in data for key in required_fields):
            return jsonify({"error": "Missing required fields"}), 400
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Insert payment into database
        cur.execute(
            """INSERT INTO payments (order_id, user_id, method, amount, status, 
            payer_name, payer_email, payer_phone, 
            upi_id) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) 
            RETURNING id""",
            (data['order_id'], session['user_id'], data['method'], data['amount'], data['status'],
             data['payer_name'], data['payer_email'], data['payer_phone'],
             data.get('upi_id'))
        )
        
        payment_id = cur.fetchone()[0]
        conn.commit()
        
        return jsonify({
            "message": "Payment processed successfully!",
            "payment_id": payment_id
        }), 201
        
    except Exception as e:
        print(f"Payment processing error: {e}")
        if 'conn' in locals():
            conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Update order payment status endpoint
@app.route("/order/update-payment", methods=["POST"])
def update_order_payment():
    if 'user_id' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        data = request.get_json()
        
        if not all(key in data for key in ['order_id', 'payment_status']):
            return jsonify({"error": "Missing required fields"}), 400
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Update order payment status
        cur.execute(
            "UPDATE orders SET payment_status = %s WHERE id = %s AND user_id = %s",
            (data['payment_status'], data['order_id'], session['user_id'])
        )
        
        if cur.rowcount == 0:
            return jsonify({"error": "Order not found or access denied"}), 404
        
        conn.commit()
        
        return jsonify({"message": "Order payment status updated successfully!"})
        
    except Exception as e:
        print(f"Order update error: {e}")
        if 'conn' in locals():
            conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Track order by ID and email
@app.route("/order/track/<int:order_id>", methods=["GET"])
def track_order(order_id):
    email = request.args.get('email')
    
    if not email:
        return jsonify({"error": "Email is required"}), 400
    
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Get order details
        cur.execute("""
            SELECT o.id, o.sender_name, o.sender_email, o.receiver_name, 
                   o.receiver_email, o.receiver_address, o.package_type, 
                   o.receiving_date, o.order_date, o.status, o.payment_status
            FROM orders o
            WHERE o.id = %s AND (o.sender_email = %s OR o.receiver_email = %s)
        """, (order_id, email, email))
        
        order = cur.fetchone()
        
        if not order:
            return jsonify({"error": "Order not found or email doesn't match"}), 404
        
        # Get tracking history
        cur.execute("""
            SELECT status, location, details, 
                   TO_CHAR(timestamp, 'YYYY-MM-DD HH24:MI') as timestamp
            FROM tracking_history 
            WHERE order_id = %s 
            ORDER BY timestamp DESC
        """, (order_id,))
        
        tracking_history = []
        for row in cur.fetchall():
            tracking_history.append({
                "status": row[0],
                "location": row[1],
                "details": row[2],
                "timestamp": row[3]
            })
        
        # Format response
        order_data = {
            "id": order[0],
            "sender_name": order[1],
            "sender_email": order[2],
            "receiver_name": order[3],
            "receiver_email": order[4],
            "receiver_address": order[5],
            "package_type": order[6],
            "receiving_date": order[7].strftime('%Y-%m-%d') if order[7] else None,
            "order_date": order[8].strftime('%Y-%m-%d %H:%M') if order[8] else None,
            "status": order[9],
            "payment_status": order[10],
            "tracking_history": tracking_history
        }
        
        return jsonify(order_data)
        
    except Exception as e:
        print(f"Track order error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

# Get all orders for the logged-in user (for tracking page)
@app.route("/user/orders", methods=["GET"])
def get_user_orders():
    if 'user_id' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Get all orders for the user with a hardcoded location
        cur.execute("""
            SELECT id, package_type, receiving_date, order_date, status
            FROM orders 
            WHERE user_id = %s 
            ORDER BY order_date DESC
        """, (session['user_id'],))
        
        rows = cur.fetchall()
        orders = []
        
        for row in rows:
            orders.append({
                "id": row[0],
                "package_type": row[1],
                "receiving_date": row[2].strftime('%Y-%m-%d') if row[2] else None,
                "order_date": row[3].strftime('%Y-%m-%d %H:%M') if row[3] else None,
                "status": row[4],
                "location": "New York Warehouse"  # Hardcoded location
            })
        
        return jsonify(orders)
        
    except Exception as e:
        print(f"Get user orders error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    app.run(debug=True)