# test_connection.py
import psycopg2

def test_connection():
    try:
        conn = psycopg2.connect(
            dbname="Delivery",
            user="postgres",
            password="1234",
            host="localhost",
            port="5432"
        )
        print("✅ Connection successful!")
        
        # Test if table exists
        cur = conn.cursor()
        cur.execute("SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'profile')")
        table_exists = cur.fetchone()[0]
        
        if table_exists:
            print("✅ Profile table exists!")
        else:
            print("❌ Profile table doesn't exist!")
            
        cur.close()
        conn.close()
        
    except Exception as e:
        print(f"❌ Connection failed: {e}")

if __name__ == "__main__":
    test_connection()